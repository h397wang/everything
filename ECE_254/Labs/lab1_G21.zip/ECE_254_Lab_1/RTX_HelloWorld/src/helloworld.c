/**
* @file: helloworld.c
* @brief: Two simple tasks running pseduo-parallelly
*/
#include <LPC17xx.h>
#include <RTL.h>
#include <stdio.h>
#include "uart_polling.h"
#include "../../RTX_CM3/INC/RTL_ext.h"

#define DEBUG 0

#if DEBUG
#define DELAY 5
#else
#define DELAY 100
#endif

__task void task0() {
    unsigned int num = 0;
    while (1) {
        num = os_tsk_count_get();
        printf("Task0: Number of non-inactive tasks: %d.\n", num);
        os_dly_wait(DELAY);
    }
}

__task void task1() {
    unsigned int i = 0;
    for(;; i++) {
        printf("Task1 counter: %d\n", i);
        os_dly_wait(DELAY);
    }
}

__task void task2() {
    while(1) {
        printf("Task2\n");
        os_dly_wait(DELAY);
    }
}

__task void task3() {
    while(1) {
        printf("Task3\n");
        os_dly_wait(DELAY);
    }
}

__task void task4() {
    unsigned int i = 0;
    for(;i < 5; i++) {
        printf("Task4 counter %d\n", i);
        os_dly_wait(DELAY);
    }
    printf("Task 4 terminating\n");
    os_tsk_delete_self();
}

__task void init(void) {
    os_tsk_create(task0, 2); 
    os_tsk_create(task1, 1); 
    os_tsk_create(task2, 1); 
    os_tsk_create(task3, 1); 
    os_tsk_create(task4, 1); 
    os_tsk_delete_self(); // must delete itself before exiting
}

int main () {
    SystemInit();
    uart0_init();
    os_sys_init(init);
}
