ECE 254 Lab 1


The function we implemented "int rt_tsk_count_get(void)" is "tested" by the HelloWorld application.
Five tasks are created with "init()". Four of the five tasks run forever. "void task4()" only runs 
for only 5 seconds, then it terminates. For the first 5 seconds, "void task0()" should print out that 
the number of active tasks is 6 (includes idle task). Afterwards, since we've deleted "void task4()", it should print out
that the number of active tasks is 5.