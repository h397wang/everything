/**
* @file: rt_Task_ext.c
*/
#include "rt_TypeDef.h"
#include "RTX_Config.h"
#include "rt_System.h"
#include "rt_Task.h"
#include "rt_List.h"
#include "rt_MemBox.h"
#include "rt_Robin.h"
#include "rt_HAL_CM.h"
#include "rt_Task_ext.h"

// I think they want us to use the helper function rt_get_TID in rt_Task.c (line 36), but it's trivial.
// That helper function basically returns the number of Active Tasks in the os_active_TCB array, but it assumes
// that the pointers are stored in the array contiguously because it breaks after NULL.
int rt_tsk_count_get (void) {
    unsigned int i;
    unsigned int taskCounter = 0;
    for (i = 0; i < os_maxtaskrun; i++) { 
        if (os_active_TCB[i] != NULL) {
            P_TCB taskPtr = (P_TCB)(os_active_TCB[i]);
            if (taskPtr->state != INACTIVE) {
                taskCounter++;
            }
        }
    }
		// Check the idle task
		if (os_idle_TCB.state != INACTIVE) {
			taskCounter++;
		}
    return taskCounter;
}
/* end of file */
